package APIServices.connection;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.http.Method;
import io.restassured.response.Response;



public class services {
    @Test
    void getProduct()
    {
        //Specify base URL
        RestAssured.baseURI="https://new.bank.ge/v1/cms/Product";
        //Request Object
        RequestSpecification httpRequest = RestAssured.given();
        //Response Object
        Response response = httpRequest.request(Method.GET,"");
        //Print Responce in Console Window
        String responseBody = response.asString();
        JsonPath j = new JsonPath(responseBody);
        String consumerLoans = j.getString("[0].description");
        System.out.println(consumerLoans);














      /*  //Status code Validation
        int statusCode = response.getStatusCode();
        System.out.println(statusCode);
        Assert.assertEquals(statusCode,200);
        //Status Line verification
        String statusLine = response.getStatusLine();
        System.out.println(statusLine);
        Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");*/
    }

}
