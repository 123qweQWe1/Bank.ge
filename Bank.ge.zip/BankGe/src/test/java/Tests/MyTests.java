package Tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageobjects.BaseTest;
import pageobjects.mainforms.CalculatorFormSalary;
import pageobjects.navigationpanel.*;

import java.util.List;


public class MyTests extends BaseTest {
    @Test(priority = 1, enabled = true, invocationCount = 1, testName = "ჰედერი")
    public void test1() throws InterruptedException {
        MainHeader mainHeader = new MainHeader(driver, wait);
        // verify main page header elements (4 element)
        mainHeader.getHeaderNavigationElements();
    }
    @Test(priority = 2,enabled = true, invocationCount = 1, testName = "მთავარი გვერდი")
    public void test2() throws InterruptedException{
        MainPage mainPage = new MainPage(driver,wait);
        // verify Main page elements text (3 element)
        mainPage.getContainerCalculatorLocator();
        Thread.sleep(5000);
    }
    @Test(priority = 3,enabled = true, invocationCount = 1, testName = "პროდუქტების გვერდი ")
    public void test3() throws InterruptedException{
        MainHeader mainHeader = new MainHeader(driver, wait);
        mainHeader.selectNavigationOptionByValue("პროდუქტები");
        ProductPage productPage = new ProductPage(driver,wait);
        // verify All Product Text (4 element)
        productPage.getAllProduct();
        Thread.sleep(5000);
    }
    @Test(priority = 4, enabled = true, invocationCount = 1, testName = "შეთავაზებების გვერდი")
    public void test4() throws InterruptedException {
        MainHeader mainHeader = new MainHeader(driver, wait);
        mainHeader.selectNavigationOptionByValue("შეთავაზებები");
        OfferPage offerPage = new OfferPage(driver, wait);
        //verify piggyBank header (1 element)
        offerPage.getPiggyBankHeader();
        //verify another offers header (1 element)
        offerPage.getAnotherOffersHeader();
        Thread.sleep(5000);
    }
    @Test(priority = 5, enabled = true, invocationCount = 1, testName = "კონტაქტების გვერდი")
    public void test5() throws InterruptedException {
        MainHeader mainHeader = new MainHeader(driver, wait);
        mainHeader.selectNavigationOptionByValue("კონტაქტი");
        ContactPage contactPage = new ContactPage(driver,wait);
        //verify contact header (3 element)
        contactPage.contactAddres();
        //verify Container Title (1 element)
        contactPage.contactContainerTitle();
        //Verify Container Box Title (41 element)
        contactPage.contactTitle();
        //verify Container Box Hour Job (41 element)
        contactPage.contactHourJob();
        contactPage.contactHourJobSaturday();
        contactPage.contactDiscrict();
        System.out.println("success");
    }
    @Test(priority = 6,enabled = true,invocationCount = 1,testName = "ფუთერი")
    public void test6() throws InterruptedException{
        FooterUI footerUI =  new FooterUI(driver,wait);
        //verify SocMediaTexts
        footerUI.getSocMediaText();
        //verify footer Phone Number
        footerUI.getphoneNumberText();
        //verfy footer Title
        footerUI.getTitleText();
        //verify footer img
        footerUI.getFooterImg();
        //verify footer Product Title
        footerUI.getFooterProductTitle();
        //verify footer All Product
        footerUI.getFooterAllProduct();
    }
    @Test(priority = 7,enabled = true,invocationCount = 1,testName = "კალკულატორის ფორმა ხელფასის მიხედვით")
    public void test7() throws InterruptedException{
        CalculatorFormSalary calculatorFormSalary = new CalculatorFormSalary(driver, wait);
        //verify Button status
        calculatorFormSalary.getCalculatorHeaderSalary();
        //verify Form Calculator Text (7 element)
        calculatorFormSalary.getCalculatorHeaderSalaryText();
    }
    @Test(priority = 8, invocationCount = 1, testName = "კალკულატორში სამომხმარებლო სესხი")
    public void test8() throws InterruptedException {
        CalculatorFormSalary calculatorFormSalary = new CalculatorFormSalary(driver, wait);
        //verify Button status
        calculatorFormSalary.getCalculatorHeaderSalary();
        //click loan type textBox
        calculatorFormSalary.clickLoanTypeTextBox();
        //select loan type
        calculatorFormSalary.selectLOanTypeByValue("სამომხმარებლო სესხი");
        //Consumer Loans checking Max Amount and month
        calculatorFormSalary.consumerLoansCheckMax();
        //Consumer Loans checking Min Amount and month
        calculatorFormSalary.consumerLoansCheckMin();
        Thread.sleep(5000);
    }
    @Test(priority = 101, invocationCount = 1, testName = "კალკულატორში საკრედიტო ბარათი")
    public void manageCalculatorCreditCard() throws InterruptedException {
        CalculatorFormSalary calculatorFormSalary = new CalculatorFormSalary(driver, wait);
        //verify Button status
        calculatorFormSalary.getCalculatorHeaderSalary();
        //click loan type textBox
        calculatorFormSalary.clickLoanTypeTextBox();
        //select loan type
        calculatorFormSalary.selectLOanTypeByValue("საკრედიტო ბარათი");
    }
    @Test(priority = 102, invocationCount = 1, testName = "კალკულატორში უზრუნველყოფილი სამომხმარებლო სესხი")
    public void manageCalculatorConsumerSecured() throws InterruptedException {
        CalculatorFormSalary calculatorFormSalary = new CalculatorFormSalary(driver, wait);
        //verify Button status
        calculatorFormSalary.getCalculatorHeaderSalary();
        //click loan type textBox
        calculatorFormSalary.clickLoanTypeTextBox();
        //select loan type
        calculatorFormSalary.selectLOanTypeByValue("უზრუნველყოფილი სამომხმარებლო სესხი");
    }
    @Test(priority = 103, invocationCount = 1, testName = "კალკულატორში იპოთეკური სესხი")
    public void manageCalculatorIpo() throws InterruptedException {
        CalculatorFormSalary calculatorFormSalary = new CalculatorFormSalary(driver, wait);
        //verify Button status
        calculatorFormSalary.getCalculatorHeaderSalary();
        //click loan type textBox
        calculatorFormSalary.clickLoanTypeTextBox();
        //select loan type
        calculatorFormSalary.selectLOanTypeByValue("იპოთეკური სესხი");
    }
    @Test(priority = 90, invocationCount = 1, testName = "raxaca")
    public void raxaca() throws InterruptedException {
        OfferPage offerPage = new OfferPage(driver, wait);
        offerPage.getPiggyBankHeader();
    }
}
