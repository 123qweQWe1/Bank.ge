package pageobjects.mainforms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilities.ActionDriver;

import java.util.ArrayList;
import java.util.List;

public class CalculatorFormSalary {
    public WebDriverWait wait;
    public WebDriver driver;

    public CalculatorFormSalary(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    By loanTypeTextBoxLocator = By.id("headlessui-listbox-button-:rf:");
    By loanTypesLocator = By.xpath("//ul/li/span[@class='block truncate font-normal']");
    By montlyIncomeLocator = By.id("montlyIncome");

    By loanDurationLocator = By.id("loanDuration");

    By loanMaxAmountLocator = By.xpath("//*[@id=\"headlessui-tabs-panel-:re:\"]/div/div[3]/div[2]/div[2]/p[2]");
    By loanMinAmountLocator = By.xpath("//*[@id=\"headlessui-tabs-panel-:re:\"]/div/div[3]/div[2]/div[2]/p[1]");

    By calculatorHeaderLocatorSalary =  By.id("headlessui-tabs-tab-:rc:");

    By calculatorHeaderLocatorSalaryText = By.xpath("//*[@id=\"headlessui-tabs-tab-:rc:\"]//p");

    By calculatorHeaderLoanTypeText = By.xpath("//*[@id=\"headlessui-tabs-panel-:re:\"]/div/div[1]/div/p");

    By montlyIncomeText = By.xpath("//*[@id=\"headlessui-tabs-panel-:re:\"]/div/div[2]/div/label");

    By loanAmountText = By.xpath("//*[@id=\"headlessui-tabs-panel-:re:\"]/div/div[3]/div/div[2]/label");

    By loanDurationText = By.xpath("//*[@id=\"headlessui-tabs-panel-:re:\"]/div/div[4]/div[1]/label");

    By calculatorHeaderTitleLocator = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[1]/span");

    By calculatorHeaderMogvmartetLocator = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[2]//span");

    By loanMinDate = By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/div/div/div/div[2]/div[1]/div[3]/div/div/div[4]/div[2]/div[2]/p[1]");

    By loanMaxDate = By.xpath("//*[@id=\"headlessui-tabs-panel-:re:\"]/div/div[4]/div[2]/div[2]/p[2]");
    public String getCalculatorHeaderSalaryText(){
        String calculatorHeaderTitleTextUI = wait.until(ExpectedConditions.visibilityOfElementLocated(calculatorHeaderTitleLocator)).getText().trim();
        String calculatorHeaderMogvmartetTextUI = wait.until(ExpectedConditions.visibilityOfElementLocated(calculatorHeaderMogvmartetLocator)).getText().trim();
        String calculatorHeaderSalaryUI = wait.until(ExpectedConditions.visibilityOfElementLocated(calculatorHeaderLocatorSalaryText)).getText().trim();
        String calculatorHeaderLoanTypeTextUI = wait.until(ExpectedConditions.visibilityOfElementLocated(calculatorHeaderLoanTypeText)).getText().trim();
        String calculatorHeadermontlyIncomeTextUI = wait.until(ExpectedConditions.visibilityOfElementLocated(montlyIncomeText)).getText().trim();
        String loanamountTextUI = wait.until(ExpectedConditions.visibilityOfElementLocated(loanAmountText)).getText().trim();
        String loanDurationTextUI = wait.until(ExpectedConditions.visibilityOfElementLocated(loanDurationText)).getText().trim();
        System.out.println(calculatorHeaderTitleTextUI);
        System.out.println(calculatorHeaderMogvmartetTextUI);
        System.out.println(calculatorHeaderSalaryUI);
        System.out.println(calculatorHeaderLoanTypeTextUI);
        System.out.println(calculatorHeadermontlyIncomeTextUI);
        System.out.println(loanamountTextUI);
        System.out.println(loanDurationTextUI);
        Assert.assertEquals(calculatorHeaderTitleTextUI,"სესხის კალკულატორი");
        Assert.assertEquals(calculatorHeaderMogvmartetTextUI,"მოგვმართეთ");
        Assert.assertEquals(calculatorHeaderSalaryUI,"ხელფასის მიხედვით");
        Assert.assertEquals(calculatorHeaderLoanTypeTextUI,"აირჩიე სესხის ტიპი");
        Assert.assertEquals(calculatorHeadermontlyIncomeTextUI,"ყოველთვიური შემოსავალი");
        Assert.assertEquals(loanamountTextUI,"სესხის თანხა");
        Assert.assertEquals(loanDurationTextUI,"სესხის ვადა");
        return calculatorHeaderLoanTypeTextUI;
    }
    public List<String> getCalculatorHeaderSalary() {
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(calculatorHeaderLocatorSalary));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options) {
            optionsTexts.add(option.getAttribute("aria-selected").trim());
        }
        System.out.println(optionsTexts);
        Assert.assertEquals(optionsTexts,List.of("true"));
        return optionsTexts;
    }
    public void consumerLoansCheckMax(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(montlyIncomeLocator)).sendKeys("7000");
        wait.until(ExpectedConditions.visibilityOfElementLocated(loanDurationLocator)).clear();
        wait.until(ExpectedConditions.visibilityOfElementLocated(loanDurationLocator)).sendKeys("36");
        String loanMaxAmountUI = wait.until(ExpectedConditions.visibilityOfElementLocated(loanMaxAmountLocator)).getText().trim();
        String loanMaxDateUI = wait.until(ExpectedConditions.visibilityOfElementLocated(loanMaxDate)).getText().trim();
        String loanmaxDate = "36 თვე";
        String loanMaxAmount = "₾80000";
        System.out.println(loanMaxAmountUI);
        System.out.println(loanMaxDateUI);
        Assert.assertEquals(loanMaxAmountUI,loanMaxAmount);
        Assert.assertEquals(loanMaxDateUI,loanmaxDate);
    }
    public void consumerLoansCheckMin(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(montlyIncomeLocator)).sendKeys("7000");
        wait.until(ExpectedConditions.visibilityOfElementLocated(loanDurationLocator)).clear();
        wait.until(ExpectedConditions.visibilityOfElementLocated(loanDurationLocator)).sendKeys("36");
        String loanMinAmountUI = wait.until(ExpectedConditions.visibilityOfElementLocated(loanMinAmountLocator)).getText().trim();
        String loanMinDateUI = wait.until(ExpectedConditions.visibilityOfElementLocated(loanMinDate)).getText().trim();
        String loanMinAmount = "₾ 100";
        String loanMinDate = "3 თვე";
        System.out.println(loanMinAmountUI);
        System.out.println(loanMinDateUI);
        Assert.assertEquals(loanMinAmountUI,loanMinAmount);
        Assert.assertEquals(loanMinDateUI,loanMinDate);
    }
    public void clickLoanTypeTextBox() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(loanTypeTextBoxLocator)).click();
    }
    public void selectLOanTypeByValue(String value) {
        ActionDriver.selectOptionByValue(wait, loanTypesLocator, value);
    }
}
