package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

public class BaseTest {
    public  static WebDriver driver;
    public  static WebDriverWait wait;
    @BeforeTest
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\irakli19\\IdeaProjects\\BankGe\\driver\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://new.bank.ge/");
    }

//    @AfterMethod
//    public void tearDown() {
//        if(driver !=null) {
//            driver.close();
//            driver.quit();
//        }
//    }
}
