package pageobjects.navigationpanel;
import com.google.errorprone.annotations.Var;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilities.ActionDriver;
import javax.lang.model.element.Element;
import java.util.ArrayList;
import java.util.List;





public class FooterUI extends  BasePage {

    public FooterUI(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }
    By socMediaButtonLocator = By.xpath("//div[@class = 'xl:gap6 flex flex-row gap-2 md:justify-self-auto lg:gap-3']//span[@class='hidden pl-2 font-BasisBankMediumCap font-light lg:inline-block']");
    By phoneNumberlocator = By.xpath("//div[@class = 'xl:gap6 flex flex-row gap-2 md:justify-self-auto lg:gap-3']//span[@class='pl-2 font-semibold ']");
    By footerTitlelocator = By.xpath("//*[@id=\"root\"]/div/div/div[3]/h1/div[1]/div[1]/div");
    By linksTextLocator = By.xpath("//*[@id=\"root\"]/div/div/div[3]/h1/div[1]/div[1]/img");
    By footerProductTitleLocator = By.xpath("//*[@class=\"font-BasisBankMediumCap font-bold\"]");
    By footerAllProductLocator = By.xpath("//*[@class=\"grid grid-cols-1 pt-8 lg:grid-cols-12 \"]//a");

    public List<String> getSocMediaText() {
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(socMediaButtonLocator));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options) {
            optionsTexts.add(option.getText().trim());
        }
        System.out.println(optionsTexts);
        Assert.assertEquals(optionsTexts,List.of("გამოგვყევი","გამოგვყევი"));
        return optionsTexts;
    }
    public void getphoneNumberText() {
        String phoneNumberUI = wait.until(ExpectedConditions.visibilityOfElementLocated(phoneNumberlocator)).getText().trim();
        String phoneNumber = "+995 32 922 922";
        System.out.println(phoneNumberUI);
        Assert.assertEquals(phoneNumberUI,phoneNumber);
    }
    public void getTitleText() {
        String titleTextUI = wait.until(ExpectedConditions.visibilityOfElementLocated(footerTitlelocator)).getText().trim();
        String titleText = "© 2022 ბაზისბანკი";
        System.out.println(titleTextUI);
        Assert.assertEquals(titleTextUI,titleText);
    }
    public List<String> getFooterImg() {
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(linksTextLocator));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options) {
            optionsTexts.add(option.getAttribute("src").trim());
        }
        System.out.println(optionsTexts);
        Assert.assertEquals(optionsTexts,List.of("https://5a52bc.netlify.app/images/logo.svg"));
        return optionsTexts;
    }
    public void getFooterProductTitle(){
        String footerProductTitleUI = wait.until(ExpectedConditions.visibilityOfElementLocated(footerProductTitleLocator)).getText().trim();
        String footerproductTitle = "პროდუქტები";
        System.out.println(footerProductTitleUI);
        Assert.assertEquals(footerProductTitleUI,footerproductTitle);

    }
    public List<String> getFooterAllProduct(){
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(footerAllProductLocator));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options){
            optionsTexts.add(option.getText().trim());
        }
        System.out.println(optionsTexts);
        Assert.assertEquals(optionsTexts,List.of("სამომხმარებლო სესხი","უზრუნველყოფილი სამომხმარებლო სესხი","იპოთეკური სესხი","საკრედიტო ბარათი"));
        return optionsTexts;
    }
}


