package pageobjects.navigationpanel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class OfferPage extends BasePage {

    public OfferPage(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }

    By piggyBankHeaderLocator = By.xpath("//div[@class='  mx-auto']//p[@class='pb-10 font-BasisBankBoldCap text-3xl']");
    By anotherOffersHeaderLocator = By.xpath("//p[@class='mx-1 justify-between text-left font-BasisBankBoldCap text-xl lg:text-2xl']");
    public void getPiggyBankHeader() {
        String piggyBankHeaderUI = wait.until(ExpectedConditions.visibilityOfElementLocated(piggyBankHeaderLocator)).getText().trim();
        String piggyBankheader = "ყულაბა";
        System.out.println(piggyBankHeaderUI);
        Assert.assertEquals(piggyBankHeaderUI,piggyBankheader);
    }

    public void getAnotherOffersHeader() {
        String anotherOffersHeaderUI = wait.until(ExpectedConditions.visibilityOfElementLocated(anotherOffersHeaderLocator)).getText().trim();
        String anotherOffersHeader = "სხვა მიმდინარე შეთავაზებები";
        System.out.println(anotherOffersHeaderUI);
        Assert.assertEquals(anotherOffersHeaderUI,anotherOffersHeader);
    }
}
