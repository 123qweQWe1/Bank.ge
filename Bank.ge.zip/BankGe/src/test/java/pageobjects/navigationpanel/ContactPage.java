package pageobjects.navigationpanel;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class ContactPage extends BasePage  {
    public ContactPage (WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }

    By ContactTitleUI = By.xpath("//*[@class=\" flex flex-col justify-around space-y-4 rounded-2xl bg-white p-8 shadow-md md:h-[256px] lg:w-full\"]/p");
    By ContactContainerTitleUI = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[2]/div/div[1]/span");

    By ContactNumberUI = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[1]/div[2]/div/div/div[1]/p/a");
    By ContactMailUI = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[1]/div[2]/div/div/div[2]/p/a");
    By ContactAddresUI = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[1]/div[2]/div/div/div[3]/p");

    By ContactHourJobUI = By.xpath("//*[@class=\" flex flex-col justify-around space-y-4 rounded-2xl bg-white p-8 shadow-md md:h-[256px] lg:w-full\"]/span//p[1]");

    By ContactHourJobSaturdayUI = By.xpath("//*[@class=\" flex flex-col justify-around space-y-4 rounded-2xl bg-white p-8 shadow-md md:h-[256px] lg:w-full\"]/span//p[2]");

    By ContactDiscrictUI = By.xpath("//*[@class=\"font-HelveticaNeueLTGEO\"]");
    public void contactAddres(){
        String contactNumberUI = wait.until(ExpectedConditions.visibilityOfElementLocated(ContactNumberUI)).getText().trim();
        String contactMailUI = wait.until(ExpectedConditions.visibilityOfElementLocated(ContactMailUI)).getText().trim();
        String contactAddresUI = wait.until(ExpectedConditions.visibilityOfElementLocated(ContactAddresUI)).getText().trim();
        String contactNumber = "+995 32 2 922 922";
        String contactMail = "bank@basisbank.ge";
        String contactAddres = "Tbilisi, Avlabari Str. 23";
        Assert.assertEquals(contactNumberUI,contactNumber);
        Assert.assertEquals(contactMailUI,contactMail);
        Assert.assertEquals(contactAddresUI,contactAddres);
    }

    public void contactContainerTitle() {
        String contactContainerTitleUI = wait.until(ExpectedConditions.visibilityOfElementLocated(ContactContainerTitleUI)).getText().trim();
        String contactContainerTitle = "ჩვენი ოფისები";
        Assert.assertEquals(contactContainerTitleUI,contactContainerTitle);
    }
    public List<String> contactTitle() {
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(ContactTitleUI));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options) {
            optionsTexts.add(option.getText().trim());
        }
        return optionsTexts;
    }
    public List<String> contactHourJob() {
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(ContactHourJobUI));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options) {
            optionsTexts.add(option.getText().trim());
        }
        return optionsTexts;
    }
    public List<String> contactHourJobSaturday() {
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(ContactHourJobSaturdayUI));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options) {
            optionsTexts.add(option.getText().trim());
        }
        return optionsTexts;
    }
    public List<String> contactDiscrict() {
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(ContactDiscrictUI));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options) {
            optionsTexts.add(option.getText().trim());
        }
        return optionsTexts;
    }
}
