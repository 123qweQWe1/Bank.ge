package pageobjects.navigationpanel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class ProductPage extends BasePage {
    public ProductPage(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }
    By allProductLocator = By.xpath("//div[@class= 'mx-auto text-center']//p[@class='w-full font-BasisBankBoldCap text-xl lg:text-3xl ']");


    public List<String> getAllProduct(){
        List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(allProductLocator));
        List<String> optionsTexts = new ArrayList<>();
        for (WebElement option : options){
            optionsTexts.add(option.getText().trim());
        }
        System.out.println(optionsTexts);
        Assert.assertEquals(optionsTexts, List.of("სამომხმარებლო სესხი","იპოთეკური სესხი","უზრუნველყოფილი სამომხმარებლო","საკრედიტო ბარათი"));
        return  optionsTexts;
    }
}
