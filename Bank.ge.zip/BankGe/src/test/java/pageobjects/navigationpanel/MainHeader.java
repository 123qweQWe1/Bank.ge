package pageobjects.navigationpanel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilities.ActionDriver;

import java.util.ArrayList;
import java.util.List;

public class MainHeader {
    public WebDriverWait wait;
    public WebDriver driver;

    public MainHeader(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    By navigationTabsLocator = By.xpath("//div[@class='flex items-center justify-end md:flex-1 ']//p");

    public void selectNavigationOptionByValue(String value) {
        ActionDriver.selectOptionByValue(wait, navigationTabsLocator, value);
    }
    public List<String> getHeaderNavigationElements() {
        List<WebElement> options =  wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(navigationTabsLocator));
        List<String> optionsTexts = new ArrayList<>();
        for(WebElement option : options) {
            optionsTexts.add(option.getText().trim());
        }
        Assert.assertEquals(optionsTexts,List.of("მთავარი", "პროდუქტები", "შეთავაზებები", "კონტაქტი"));
        return optionsTexts;
    }
}
