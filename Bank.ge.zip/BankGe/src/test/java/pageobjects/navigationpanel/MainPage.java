package pageobjects.navigationpanel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.concurrent.ExecutionException;

public class MainPage extends BasePage {
    public MainPage(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }
    By containerCalculatorLocator = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[1]/span");
    By ourProductsLocator = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[2]/div[3]/div/div/div[1]/p");

    By anotherOffersLocator = By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[3]/div/div/div[1]/p");

    public String getContainerCalculatorLocator (){
        String getContainerCalculatorLocatorUI = wait.until(ExpectedConditions.visibilityOfElementLocated(containerCalculatorLocator)).getText().trim();
        String getourProductsLocatorUI = wait.until(ExpectedConditions.visibilityOfElementLocated(ourProductsLocator)).getText().trim();
        String getanotherOffersLocatorUI =  wait.until(ExpectedConditions.visibilityOfElementLocated(anotherOffersLocator)).getText().trim();
        System.out.println(getContainerCalculatorLocatorUI);
        System.out.println(getourProductsLocatorUI);
        System.out.println(getanotherOffersLocatorUI);
        Assert.assertEquals(getContainerCalculatorLocatorUI,"სესხის კალკულატორი");
        Assert.assertEquals(getourProductsLocatorUI,"ჩვენი პროდუქტები");
        Assert.assertEquals(getanotherOffersLocatorUI,"სხვა მიმდინარე შეთავაზებები");
        return getContainerCalculatorLocatorUI;
    }
}
